// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Dec 2020
// This program calculates squares

#include <iostream>
#include <string>
#include <cmath>

int main() {
    int im;
    int loop;
    int ex;
    std::string imAsString;

    // input
    std::cout << "Enter a positive integer: ";
    std::cin >> imAsString;
    std::cout << "" << std::endl;

    try {
        im = std::stoi(imAsString);

        if (im >= 0) {
            for (loop = 0; loop <= im; loop++) {
                ex = pow(loop, 2);
            } std::cout << imAsString << "² is " << ex << std::endl;
        } else {
            std::cout << "That is a negative integer." << std::endl;
        }
    } catch (std::invalid_argument) {
        std::cout << "That is not an integer" << std::endl;
    }
}
